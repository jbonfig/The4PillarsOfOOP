﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace The4PillarsOfOOP.Models
{
    class Capacitor : Component
    {
        private double value;
        private double tolerance;
        private string units;

        public string str;

        public Capacitor(string pn, double val, double tol)
        {
            partnum = pn;
            type = "Capacitor";
            value = val;
            units = "uFD";
            tolerance = tol;

            str = (partnum + ": " + type + "; " + value + " " + units + "; " + tolerance + "%");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace The4PillarsOfOOP.Models
{
    class Generic : Component
    {
        public string str;

        public Generic(string pn)
        {
            partnum = pn;
            type = "Generic";

            str = (partnum + ": " + type);
        }
    }
}
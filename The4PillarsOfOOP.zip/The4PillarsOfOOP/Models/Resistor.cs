﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace The4PillarsOfOOP.Models
{
    public class Resistor : Component
    {
        private double value;
        private string units, power, tolerance;

        public string str;

        public Resistor(string pn, double val, string pwr, double tol)
        {
            partnum = pn;
            type = "Resistor";
            value = val;
            units = "Ohms";
            power = pwr;
            tolerance = (Convert.ToString(tol)) + "%";

            str = (partnum + ": " + type + "; " + value + " " + units + "; " + power + "; " + tolerance);
        }

        public Resistor(string pn, double val)
        {
            partnum = pn;
            type = "Varistor";
            value = val;
            units = "Ohms";

            str = (partnum + ": " + type + "; " + value + " " + units);
        }
    }
}
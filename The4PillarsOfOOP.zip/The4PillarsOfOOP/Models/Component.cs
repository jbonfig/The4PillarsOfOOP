﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace The4PillarsOfOOP.Models
{
    public abstract class Component
    {
        public string partnum;
        public string type;
    }
}
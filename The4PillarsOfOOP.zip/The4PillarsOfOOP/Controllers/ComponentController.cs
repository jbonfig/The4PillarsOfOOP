﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using The4PillarsOfOOP.Models;

namespace The4PillarsOfOOP.Controllers
{
    public class ComponentController : Controller
    {
        // GET: Component

        private List<string> components = new List<string>();

        public ActionResult Get()
        {
            Resistor r = new Resistor("24004569", 5.6, "1/2W", 0.5);
            components.Add(r.str);

            Resistor v = new Resistor("24009122", 10000);
            components.Add(v.str);

            Capacitor c = new Capacitor("16003291", 0.01, 10);
            components.Add(c.str);

            Generic g = new Generic("56008760");
            components.Add(g.str);

            components.Sort();

            ViewData["vals"] = components;

            return View();
        }
    }
}
